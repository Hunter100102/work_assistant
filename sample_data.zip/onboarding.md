# Client Onboarding Checklist
1. Domain access (registrar login or DNS records)
2. Brand assets (logo, colors, fonts)
3. Content (about, services, pricing, photos)
4. Admin emails for alerts
5. Preferred support contact method
